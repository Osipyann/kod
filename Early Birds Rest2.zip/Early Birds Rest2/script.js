let burger_menu = document.querySelector('.burger_menu');
if(burger_menu){
    let click_menu = document.querySelector('.click_menu');
    burger_menu.addEventListener("click", function(e){
        // document.body.classList.toggle('_lock');
        burger_menu.classList.toggle('_active');
        click_menu.classList.toggle('_active');
    })
        let mobToggle1 = document.querySelector('#mobToggle1');
        mobToggle1.addEventListener("click", () =>{
            burger_menu.classList.toggle('_active');
            click_menu.classList.toggle('_active');
        })

        let mobToggle2 = document.querySelector('#mobToggle2');
        mobToggle2.addEventListener("click", () =>{
            burger_menu.classList.toggle('_active');
            click_menu.classList.toggle('_active');
        })

        let mobToggle3 = document.querySelector('#mobToggle3');
        mobToggle3.addEventListener("click", () =>{
            burger_menu.classList.toggle('_active');
            click_menu.classList.toggle('_active');
        })

        let mobToggle4 = document.querySelector('#mobToggle4');
        mobToggle4.addEventListener("click", () =>{
            burger_menu.classList.toggle('_active');
            click_menu.classList.toggle('_active');
        })

        let mobToggle5 = document.querySelector('#mobToggle5');
        mobToggle5.addEventListener("click", () =>{
            burger_menu.classList.toggle('_active');
            click_menu.classList.toggle('_active');
        })

        let mobToggle6 = document.querySelector('#mobToggle6');
        mobToggle6.addEventListener("click", () =>{
            burger_menu.classList.toggle('_active');
            click_menu.classList.toggle('_active');
        })
        
}

